from flask import Flask, request, jsonify, render_template
import sqlite3

app = Flask(__name__)
DATABASE = "students.db"


def connect_database():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection


def create_table():
    connection = connect_database()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            roll_no INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            marks INTEGER NOT NULL
        )
    """)

    connection.commit()
    connection.close()


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/students", methods=["GET"])
def get_students():
    connection = connect_database()
    students = connection.execute(
        "SELECT * FROM students ORDER BY roll_no"
    ).fetchall()
    connection.close()

    return jsonify([
        {
            "roll_no": student["roll_no"],
            "name": student["name"],
            "marks": student["marks"]
        }
        for student in students
    ])


@app.route("/students", methods=["POST"])
def add_student():
    data = request.get_json()

    if not data:
        return jsonify({"message": "No data received!"}), 400

    roll_no = data.get("roll_no")
    name = data.get("name")
    marks = data.get("marks")

    if not isinstance(roll_no, int) or roll_no <= 0:
        return jsonify({"message": "Roll No must be a positive number!"}), 400

    if not isinstance(name, str) or not name.strip():
        return jsonify({"message": "Name is required!"}), 400

    if not isinstance(marks, int) or marks < 0 or marks > 100:
        return jsonify({"message": "Marks must be between 0 and 100!"}), 400

    connection = connect_database()

    existing = connection.execute(
        "SELECT roll_no FROM students WHERE roll_no = ?",
        (roll_no,)
    ).fetchone()

    if existing:
        connection.close()
        return jsonify({"message": "Roll No already exists!"}), 400

    connection.execute(
        "INSERT INTO students (roll_no, name, marks) VALUES (?, ?, ?)",
        (roll_no, name.strip(), marks)
    )

    connection.commit()
    connection.close()

    return jsonify({"message": "Student added successfully!"}), 201


@app.route("/students/<int:roll_no>", methods=["GET"])
def search_student(roll_no):
    connection = connect_database()

    student = connection.execute(
        "SELECT * FROM students WHERE roll_no = ?",
        (roll_no,)
    ).fetchone()

    connection.close()

    if student is None:
        return jsonify({"message": "Student not found!"}), 404

    return jsonify({
        "roll_no": student["roll_no"],
        "name": student["name"],
        "marks": student["marks"]
    })


@app.route("/students/<int:roll_no>", methods=["PUT"])
def update_student(roll_no):
    data = request.get_json()

    if not data:
        return jsonify({"message": "No data received!"}), 400

    name = data.get("name")
    marks = data.get("marks")

    if not isinstance(name, str) or not name.strip():
        return jsonify({"message": "Name is required!"}), 400

    if not isinstance(marks, int) or marks < 0 or marks > 100:
        return jsonify({"message": "Marks must be between 0 and 100!"}), 400

    connection = connect_database()

    existing = connection.execute(
        "SELECT roll_no FROM students WHERE roll_no = ?",
        (roll_no,)
    ).fetchone()

    if existing is None:
        connection.close()
        return jsonify({"message": "Student not found!"}), 404

    connection.execute(
        "UPDATE students SET name = ?, marks = ? WHERE roll_no = ?",
        (name.strip(), marks, roll_no)
    )

    connection.commit()
    connection.close()

    return jsonify({"message": "Student updated successfully!"})


@app.route("/students/<int:roll_no>", methods=["DELETE"])
def delete_student(roll_no):
    connection = connect_database()

    existing = connection.execute(
        "SELECT roll_no FROM students WHERE roll_no = ?",
        (roll_no,)
    ).fetchone()

    if existing is None:
        connection.close()
        return jsonify({"message": "Student not found!"}), 404

    connection.execute(
        "DELETE FROM students WHERE roll_no = ?",
        (roll_no,)
    )

    connection.commit()
    connection.close()

    return jsonify({"message": "Student deleted successfully!"})


create_table()

if __name__ == "__main__":
    app.run(debug=True)
