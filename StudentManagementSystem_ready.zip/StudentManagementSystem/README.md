# Student Management System

A beginner-friendly full-stack Student Management System.

## Technologies
- Python
- Flask
- SQLite
- HTML
- CSS
- JavaScript

## Features
- Add student
- Display students
- Search student
- Update student
- Delete student
- Duplicate roll number protection
- Marks validation
- Responsive interface

## Run
1. Install Python.
2. Open this project folder in a terminal.
3. Install Flask:
   `pip install -r requirements.txt`
4. Start:
   `python app.py`
5. Open:
   `http://127.0.0.1:5000`

The `students.db` file is created automatically when the application starts.
