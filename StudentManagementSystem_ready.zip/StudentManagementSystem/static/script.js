async function loadStudents() {
    try {
        const response = await fetch("/students");
        const students = await response.json();

        const table = document.getElementById("studentTable");
        table.innerHTML = "";

        if (students.length === 0) {
            table.innerHTML = `
                <tr>
                    <td colspan="4">No students available</td>
                </tr>
            `;
            return;
        }

        students.forEach(student => {
            const row = document.createElement("tr");

            row.innerHTML = `
                <td>${student.roll_no}</td>
                <td>${student.name}</td>
                <td>${student.marks}</td>
                <td>
                    <button class="action-button"
                            onclick="editStudent(${student.roll_no})">
                        Edit
                    </button>
                    <button class="action-button"
                            onclick="deleteStudent(${student.roll_no})">
                        Delete
                    </button>
                </td>
            `;

            table.appendChild(row);
        });
    } catch (error) {
        alert("Could not connect to the server.");
        console.error(error);
    }
}


async function addStudent() {
    const rollNo = document.getElementById("rollNo").value;
    const name = document.getElementById("name").value.trim();
    const marks = document.getElementById("marks").value;

    if (!rollNo || !name || marks === "") {
        alert("Please fill all fields!");
        return;
    }

    const response = await fetch("/students", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            roll_no: Number(rollNo),
            name: name,
            marks: Number(marks)
        })
    });

    const result = await response.json();
    alert(result.message);

    if (response.ok) {
        document.getElementById("rollNo").value = "";
        document.getElementById("name").value = "";
        document.getElementById("marks").value = "";
        loadStudents();
    }
}


async function searchStudent() {
    const rollNo = document.getElementById("searchRollNo").value;

    if (!rollNo) {
        alert("Enter a Roll No!");
        return;
    }

    const response = await fetch(`/students/${rollNo}`);
    const result = await response.json();

    const searchResult = document.getElementById("searchResult");

    if (!response.ok) {
        searchResult.innerHTML = `<p>${result.message}</p>`;
        return;
    }

    searchResult.innerHTML = `
        <strong>Roll No:</strong> ${result.roll_no}<br>
        <strong>Name:</strong> ${result.name}<br>
        <strong>Marks:</strong> ${result.marks}
    `;
}


function clearSearch() {
    document.getElementById("searchRollNo").value = "";
    document.getElementById("searchResult").innerHTML = "";
}


async function editStudent(rollNo) {
    const name = prompt("Enter new name:");

    if (name === null) {
        return;
    }

    const marks = prompt("Enter new marks (0-100):");

    if (marks === null) {
        return;
    }

    const response = await fetch(`/students/${rollNo}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name: name.trim(),
            marks: Number(marks)
        })
    });

    const result = await response.json();
    alert(result.message);

    if (response.ok) {
        loadStudents();
    }
}


async function deleteStudent(rollNo) {
    const confirmDelete = confirm(
        "Are you sure you want to delete this student?"
    );

    if (!confirmDelete) {
        return;
    }

    const response = await fetch(`/students/${rollNo}`, {
        method: "DELETE"
    });

    const result = await response.json();
    alert(result.message);

    loadStudents();
}


loadStudents();
